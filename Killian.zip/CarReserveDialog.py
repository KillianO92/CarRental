#TODO:  Find out why the import names must be unique
import tkinter as CRTK
from tkinter import messagebox
from CustDBFunctions import *
from CarsDBFunctions import *
from ResDBFunctions import *
from WindowFunctions import *

cstDB = CustDBFunctions()
carDB = CarsDBFunctions()
resDB = ResDBFunctions()

class CarReserveDialog(object):
    root = None


    def __init__(self, parent):
        """
        msg = <str> the message to be displayed
        dict_key = <sequence> (dictionary, key) to associate with user input
        (providing a sequence for dict_key creates an entry for user input)
        """
        app = parent.root
        self._w = CRTK.Toplevel(parent.root)

        self.CarRentedEvent = CRTK.Event
        self.frm = CRTK.Frame(self._w, borderwidth=4, relief='ridge')
        self.frm.pack(fill='both', expand=True)

        self.carID = parent.carID
        output = carDB.loadCarsByID(self.carID)
        for dat in output:
            string = '{} {} {}'.format(dat[2], dat[0], dat[1])


        self.label = CRTK.Label(self.frm, text="Reserving Vehicle: {}".format(string))
        self.label.pack(padx=4, pady=4)

        self.lblCust = CRTK.Label(self.frm, text="Select the Customer Renting the Car")
        self.lblCust.pack(padx=4, pady=4)


        self.customer_value = CRTK.StringVar()
        self.cbpMakes = CRTK.ttk.Labelframe(self.frm, text='List of Car Makes')
        self.cbMakes = CRTK.ttk.Combobox(self.frm, textvariable=self.customer_value, width=50,  state="readonly")
        self.cbMakes['values'] = cstDB.loadCustomers()
        self.cbMakes.pack(pady=4, padx=4)


        self.lblStart = CRTK.Label(self.frm, text='Start Date')
        self.lblStart.pack(padx=4, pady=4)
        self.entryStart = CRTK.Entry(self.frm)
        self.entryStart.pack(pady=4, padx=4)
        self.entryStart.insert(0, 'MM-DD-YYYY')

        self.lblEnd = CRTK.Label(self.frm, text = 'End Date')
        self.lblEnd.pack(padx=4, pady=4)
        self.entryEnd = CRTK.Entry(self.frm)
        self.entryEnd.pack(pady=4, padx=4)
        self.entryEnd.insert(0, 'MM-DD-YYYY')

        self.b_cancel = CRTK.Button(self.frm, text='Cancel')
        self.b_cancel['command'] = self._w.destroy
        self.b_cancel.pack(padx=4, pady=4)    

        self.b_OK = CRTK.Button(self.frm, text='OK')
        self.b_OK['command'] = self.rentCar
        self.b_OK.pack(padx=4, pady=4)
        WindowFunctions.center(self._w)
        
        
    def FormatDates(self, dateValue):
         dtElements = dateValue.split("-")
         dtFormat = ''
         if len(dtElements) > 1:
            dtFormat = "{:<2}/{:<2}/{:<4}".format(dtElements[0],dtElements[1],dtElements[2])
         return dtFormat 

    def rentCar(self):
        cus = self.customer_value.get()
        spacePos = cus.find(' ')
        custID= cus[0:spacePos]
        if custID == '':
            messagebox.showwarning("Data Error", "CustomerID required")
              
        elif self.entryStart.get() == '' or self.entryStart.get() == "MM-DD-YYYY":
             messagebox.showwarning("Data Error", "Start Date required")
        elif self.entryEnd.get() == '' or self.entryEnd.get() == "MM-DD-YYYY":
            messagebox.showwarning("Data Error", "End Date required")
        else:
            sDate = self.FormatDates(self.entryStart.get())
            eDate = self.FormatDates(self.entryEnd.get())

            resDB.AddNewReservation(self.carID, custID, sDate, eDate)

        self._w.lift()
        



