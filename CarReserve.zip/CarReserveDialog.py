#TODO:  Find out why the import names must be unique
import tkinter as CRTK
from tkinter import messagebox
from CustDBFunctions import *
from CarsDBFunctions import *
from ResDBFunctions import *
from WindowFunctions import *

cstDB = CustDBFunctions()
carDB = CarsDBFunctions()
resDB = ResDBFunctions()

class CarReserveDialog(object):
    root = None


    def __init__(self, parent):
        """
        msg = <str> the message to be displayed
        dict_key = <sequence> (dictionary, key) to associate with user input
        (providing a sequence for dict_key creates an entry for user input)
        """
        app = parent.root
        self._w = CRTK.Toplevel(parent.root)

        self.CarRentedEvent = CRTK.Event
        self.frm = CRTK.Frame(self._w, borderwidth=4, relief='ridge')
        self.frm.pack(fill='both', expand=True)

        self.carID = parent.carID
        output = carDB.loadCarsByID(self.carID)
        for dat in output:
            string = '{} {} {}'.format(dat[2], dat[0], dat[1])


        self.label = CRTK.Label(self.frm, text="Reserving Vehicle: {}".format(string))
        self.label.pack(padx=4, pady=4)

        self.lblCust = CRTK.Label(self.frm, text="Select the Customer Renting the Car")
        self.lblCust.pack(padx=4, pady=4)


        self.customer_value = CRTK.StringVar()
        self.cbpMakes = CRTK.ttk.Labelframe(self.frm, text='List of Car Makes')
        self.cbMakes = CRTK.ttk.Combobox(self.frm, textvariable=self.customer_value, width=50,  state="readonly")
        self.cbMakes['values'] = cstDB.loadCustomers()
        self.cbMakes.pack(pady=4, padx=4)


        self.lblStart = CRTK.Label(self.frm, text='Start Date')
        self.lblStart.pack(padx=4, pady=4)
        self.entryStart = CRTK.Entry(self.frm)
        self.entryStart.pack(pady=4, padx=4)
        self.entryStart.insert(0, 'MM-DD-YYYY')

        self.lblEnd = CRTK.Label(self.frm, text = 'End Date')
        self.lblEnd.pack(padx=4, pady=4)
        self.entryEnd = CRTK.Entry(self.frm)
        self.entryEnd.pack(pady=4, padx=4)
        self.entryEnd.insert(0, 'MM-DD-YYYY')

        self.entryEnd.bind("<FocusOut>", self.dates)

        self.b_cancel = CRTK.Button(self.frm, text='Cancel')
        self.b_cancel['command'] = self._w.destroy
        self.b_cancel.pack(padx=4, pady=4)    

        self.b_OK = CRTK.Button(self.frm, text='OK')
        self.b_OK['command'] = self.rentCar
        self.b_OK.pack(padx=4, pady=4)

        WindowFunctions.center(self._w)
        self._w.lift()

    def dates(self, parent):
        name = ''
        string = ''
        string2 = ''
        if self.customer_value.get() == '':
            name = "Customer\n"
        if self.entryStart.get() == "MM-DD-YYYY" or self.entryStart.get() =='' or len(self.entryStart.get()) != 10:
            string = "Start Date\n"
        if self.entryEnd.get() == "MM-DD-YYYY" or self.entryEnd.get() =='' or len(self.entryEnd.get()) != 10:
            string2 = "End Date\n"
        else:
            return
        messagebox.showerror("Dates", "Still Require:\n{}{}{}".format(name, string, string2))

        self._w.lift()
        
    def FormatDates(self, dateValue):
         dtElements = dateValue.split("-")
         dtFormat = ''
         if len(dtElements) > 1:
            dtFormat = "{:<4}-{:<2}-{:<2}".format(dtElements[2],dtElements[0],dtElements[1])
         return dtFormat 

    def rentCar(self):
        cus = self.customer_value.get()
        spacePos = cus.find(' ')
        self.custID= cus[0:spacePos]
        sDate = self.FormatDates(self.entryStart.get())
        eDate = self.FormatDates(self.entryEnd.get())


        resDB.AddNewReservation(self.carID, self.custID, sDate, eDate)
        self._w.lift()
        self.popup()

    
    def popup(self):
        self.win = CRTK.Toplevel()
        self.win.wm_title("Reservation")

        self.lblNo = CRTK.Label(self.win, text="Reservation was Added\n\n")
        self.lblNo.grid(row=0, column=0)


        self.btnOK = CRTK.ttk.Button(self.win, text="Okay", command=self.closeAll)
        self.btnOK.grid(row=1, column=0)

        self.lblEmpty = CRTK.Label(self.win, text=" ")
        self.lblEmpty.grid(row=2, column=0)
        WindowFunctions.center(self.win)

    def closeAll(self):
        self._w.destroy()
        self.win.destroy()
        
        



