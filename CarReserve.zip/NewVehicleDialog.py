import tkinter as NVTK
from tkinter import messagebox
from CustDBFunctions import *
from CarsDBFunctions import *
from ResDBFunctions import *
from BaseDBFunctions import *
from CustFunctions import *
from WindowFunctions import *

cstDB = CustDBFunctions()
carDB = CarsDBFunctions()
resDB = ResDBFunctions()
baseDB = BaseDBFunctions()

class NewVehicleDialog(object):
    root = None

    def MakeSelected(self, event):
        make = self.make_value.get()
        spacePos = make.find(' ')
        MakeID = make[0:spacePos]
        self.cbModels['values'] = carDB.loadCarModels(MakeID)


    def __init__(self, parent):
        """
        msg = <str> the message to be displayed
        dict_key = <sequence> (dictionary, key) to associate with user input
        (providing a sequence for dict_key creates an entry for user input)
        """
        
        self._w = NVTK.Toplevel(parent.master)
        self.frm = NVTK.Frame(self._w, borderwidth=4, relief='ridge')
        self.frm.pack(fill='both', expand=True)

        self.label = NVTK.Label(self.frm, text="Add New Vehicle")
        self.label.pack(padx=4, pady=4)

        self.lblMake = NVTK.Label(self.frm, text='Make')
        self.lblMake.pack(padx=4, pady=4)

        self.make_value = NVTK.StringVar()
        self.cbMakes = NVTK.ttk.Combobox(self.frm, textvariable=self.make_value, width=50, state="readonly")
        self.cbMakes['values'] = carDB.loadCarMakes()
        self.cbMakes.bind("<<ComboboxSelected>>", self.MakeSelected)
        self.cbMakes.pack(pady=4, padx=4)


        #TODO make it so once make is selected it changes MakeID
        make = self.make_value.get()
        spacePos = make.find(' ')
        MakeID = make[0:spacePos]

        self.lblModel = NVTK.Label(self.frm, text = 'Model')
        self.lblModel.pack(padx=4, pady=4)

        self.model_value = NVTK.StringVar()
        self.cbModels = NVTK.ttk.Combobox(self.frm, textvariable=self.model_value, width=50, state="readonly")
        if (MakeID == ''):
            for dat in self.cbModels.get():
                self.cbModels.set('')
        else:
            self.cbModels['values'] = carDB.loadCarModels(MakeID)
        self.cbModels.pack(pady=4, padx=4)

        self.lblModelNew = NVTK.Label(self.frm, text="If Model not present input here")
        self.lblModelNew.pack(padx=4, pady=4)
        self.entryModel = NVTK.Entry(self.frm)
        self.entryModel.pack(pady=4, padx=4)

        self.lblDoor = NVTK.Label(self.frm, text = 'Doors')
        self.lblDoor.pack(padx=4, pady=4)
        self.entryDoor = NVTK.Entry(self.frm)
        self.entryDoor.pack(pady=4, padx=4)
        

        self.lblColor = NVTK.Label(self.frm, text = 'Color')
        self.lblColor.pack(padx=4, pady=4)
        self.entryColor = NVTK.Entry(self.frm)
        self.entryColor.pack(pady=4, padx=4)

        self.b_cancel = NVTK.Button(self.frm, text='Cancel')
        self.b_cancel['command'] = self._w.destroy
        self.b_cancel.pack(padx=4, pady=4)    

        self.b_OK = NVTK.Button(self.frm, text='OK')
        self.b_OK['command'] = self.addVehicle
        self.b_OK.pack(padx=4, pady=4)
        WindowFunctions.center(self._w)

    def addVehicle(self):
        make = self.make_value.get()
        spacePos = make.find(' ')
        MakeID = make[0:spacePos]
        if self.model_value.get() == '' and self.entryModel.get() == '':
            messagebox.showerror("Make and Model", "Please select a Make and Model")          
        elif self.entryDoor.get() == '':
            messagebox.showerror("Doors Needed", "Please select a number of doors")
        elif self.entryColor.get() == '':
            messagebox.showerror("Color Needed", "Please select a vehicle Ccolor")
        else:
            if self.model_value.get() == '':
                Model = self.entryModel.get()
            else:
                Model = self.model_value.get()
            Color = self.entryColor.get()
            Doors = self.entryDoor.get()

            carDB.AddVehicle(MakeID, Model, Color, Doors)
            messagebox.showinfo("Committed Record", "Vehicle has been added")
            self._w.destroy()



 
