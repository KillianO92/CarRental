import tkinter as CETK
from tkinter import messagebox
from CustDBFunctions import *
from CarsDBFunctions import *
from ResDBFunctions import *
from BaseDBFunctions import *
from CustFunctions import *
from WindowFunctions import *


cstDB = CustDBFunctions()
carDB = CarsDBFunctions()
resDB = ResDBFunctions()
baseDB = BaseDBFunctions()

class CustEditDialog(object):
    root = None

    def __init__(self, parent):
        """
        msg = <str> the message to be displayed
        dict_key = <sequence> (dictionary, key) to associate with user input
        (providing a sequence for dict_key creates an entry for user input)
        """
        
        self._w = CETK.Toplevel(parent.root)
        self.frm = CETK.Frame(self._w, borderwidth=4, relief='ridge')
        self.frm.pack(fill='both', expand=True)

        self.custID = parent.custID

        output = cstDB.loadCustomerByID(self.custID)
        self.Fname = output[0][1]
        self.Lname = output[0][2]
        self.num = output[0][3]



        self.label = CETK.Label(self.frm, text="Editing: {} {}".format(self.Fname, self.Lname))
        self.label.pack(padx=4, pady=4)

        self.lblFname = CETK.Label(self.frm, text='First Name')
        self.lblFname.pack(padx=4, pady=4)
        self.entryFname = CETK.Entry(self.frm)
        self.entryFname.pack(pady=4, padx=4)
        self.entryFname.insert(0, self.Fname)


        self.lblLname = CETK.Label(self.frm, text = 'Last Name')
        self.lblLname.pack(padx=4, pady=4)
        self.entryLname = CETK.Entry(self.frm)
        self.entryLname.pack(pady=4, padx=4)
        self.entryLname.insert(0, self.Lname)

        self.lblnum = CETK.Label(self.frm, text = 'Phone self.number')
        self.lblnum.pack(padx=4, pady=4)
        self.entrynum = CETK.Entry(self.frm)
        self.entrynum.pack(pady=4, padx=4)
        self.entrynum.insert(0, self.num)

        self.b_cancel = CETK.Button(self.frm, text='Cancel')
        self.b_cancel['command'] = self._w.destroy
        self.b_cancel.pack(padx=4, pady=4)    

        self.b_OK = CETK.Button(self.frm, text='OK')
        self.b_OK['command'] = self.updateCust
        self.b_OK.pack(padx=4, pady=4)

        WindowFunctions.center(self._w)

    def updateCust(self):
        if self.entryFname.get() == self.Fname and self.entryLname.get() == self.Lname and self.entrynum.get() == self.num:
            messagebox.showinfo("Data", "No changes made")
            self.frm.destroy()
        else:
            FirstName = self.entryFname.get()
            LastName = self.entryLname.get()
            Phonenumber = self.entrynum.get()
            CustomerID = self.custID
            print("Updated\nFName: '{}'\nLName: '{}'\nPhoneNumber: '{}'".format(FirstName, LastName, Phonenumber))
            cstDB.UpdateCustomer(FirstName, LastName, Phonenumber, CustomerID)
            messagebox.showinfo("Data", "Changes committed")
            self._w.destroy()

        
        

        



