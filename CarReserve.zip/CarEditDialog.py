import tkinter as CARTK
#from tkinter import messagebox
from CustDBFunctions import *
from CarsDBFunctions import *
from ResDBFunctions import *
from BaseDBFunctions import *
from CustFunctions import *
from WindowFunctions import *

cstDB = CustDBFunctions()
carDB = CarsDBFunctions()
resDB = ResDBFunctions()
baseDB = BaseDBFunctions()

class CarEditDialog(object):
    root = None

    def __init__(self, parent):
        """
        msg = <str> the message to be displayed
        dict_key = <sequence> (dictionary, key) to associate with user input
        (providing a sequence for dict_key creates an entry for user input)
        """

        app = parent.root
        self._w = CARTK.Toplevel(parent.root)
        self.frm = CARTK.Frame(self._w, borderwidth=4, relief='ridge')
        self.frm.pack(fill='both', expand=True)

        self.carID = parent.carID

        output = carDB.loadCarsByID(self.carID)
        self.make = output[0][0]
        self.model = output[0][1]
        self.doors = output[0][2]
        self.color = output[0][3]
        



        self.label = CARTK.Label(self.frm, text="Editing: {} {} {}".format(self.color, self.make, self.model))
        self.label.pack(padx=4, pady=4)


        self.lblModel = CARTK.Label(self.frm, text = 'Model')
        self.lblModel.pack(padx=4, pady=4)
        self.entryModel = CARTK.Entry(self.frm)
        self.entryModel.pack(pady=4, padx=4)
        self.entryModel.insert(0, self.model)

        self.lblDoors = CARTK.Label(self.frm, text = 'Doors')
        self.lblDoors.pack(padx=4, pady=4)
        self.entryDoors = CARTK.Entry(self.frm)
        self.entryDoors.pack(pady=4, padx=4)
        self.entryDoors.insert(0, self.doors)

        self.lblColor = CARTK.Label(self.frm, text = 'Color')
        self.lblColor.pack(padx=4, pady=4)
        self.entryColor = CARTK.Entry(self.frm)
        self.entryColor.pack(pady=4, padx=4)
        self.entryColor.insert(0, self.color)

        self.b_cancel = CARTK.Button(self.frm, text='Cancel')
        self.b_cancel['command'] = self._w.destroy
        self.b_cancel.pack(padx=4, pady=4)    

        self.b_OK = CARTK.Button(self.frm, text='OK')
        self.b_OK['command'] = self.updateCar
        self.b_OK.pack(padx=4, pady=4)

        WindowFunctions.center(self._w)

        
        

    def updateCar(self):
        Model = self.entryModel.get()
        Doors = self.entryDoors.get()
        Color = self.entryColor.get()
        CarID = self.carID
        
        if Model != self.model or Doors != self.doors or Color != self.color:
            carDB.UpdateCar(Model, Doors, Color, CarID)
            messagebox.showinfo("Vehicle Update", "The vehicle has been updated")
            self._w.destroy()
        else:
            messagebox.showinfo("Vehicle Update", "No information updated")
            self._w.destroy()

        
        

        



